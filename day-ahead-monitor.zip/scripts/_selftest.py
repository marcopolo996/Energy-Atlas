"""Offline checks. Not needed in production, safe to delete."""
import json
import math
import sys
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from fetch_prices import (  # noqa: E402
    compute_metrics,
    local_day_bounds,
    optimise_battery,
    parse_series,
    to_local_hours,
)

# --- 1. XML parsing, hourly, with an omitted repeating position -------------
def build_xml(resolution, values, start="2026-08-22T22:00Z"):
    pts = "".join(
        f"<Point><position>{i+1}</position><price.amount>{v}</price.amount></Point>"
        for i, v in enumerate(values)
        if v is not None
    )
    return f"""<?xml version="1.0"?>
<Publication_MarketDocument xmlns="urn:iec62325.351:tc57wg16:451-3:publicationdocument:7:0">
 <TimeSeries><Period>
  <timeInterval><start>{start}</start><end>2026-08-23T22:00Z</end></timeInterval>
  <resolution>{resolution}</resolution>
  {pts}
 </Period></TimeSeries>
</Publication_MarketDocument>"""


hourly = [80, None, 60, 55, 50, 48, 55, 70, 95, 110, 90, 60,
          20, -5, -12, 10, 45, 88, 130, 165, 150, 120, 100, 85]
series = parse_series(build_xml("PT60M", hourly))
assert len(series) == 24, len(series)
prices = to_local_hours(series, date(2026, 8, 23), "Europe/Berlin")
assert prices is not None and len(prices) == 24
assert prices[1] == 80.0, f"forward fill failed: {prices[1]}"
assert prices[14] == -12.0
print("hourly parse + forward fill    OK")

# --- 2. Quarter-hourly resolution averaged up to hours ----------------------
quarter = []
for v in hourly:
    base = 80 if v is None else v
    quarter += [base - 2, base, base, base + 2]
series_q = parse_series(build_xml("PT15M", quarter))
assert len(series_q) == 96, len(series_q)
prices_q = to_local_hours(series_q, date(2026, 8, 23), "Europe/Berlin")
assert prices_q is not None and len(prices_q) == 24
assert abs(prices_q[9] - 110.0) < 0.01, prices_q[9]
print("quarter-hourly averaging       OK")

# --- 3. Timezone window, including a DST day -------------------------------
s, e = local_day_bounds(date(2026, 8, 23), "Europe/Rome")
assert (s, e) == ("202608222200", "202608232200"), (s, e)
s2, e2 = local_day_bounds(date(2026, 1, 15), "Europe/Rome")
assert (s2, e2) == ("202601142300", "202601152300"), (s2, e2)
print("timezone windows               OK")

# --- 4. Dispatch optimiser sanity ------------------------------------------
flat = optimise_battery([50.0] * 24)
assert abs(flat["revenue"]) < 1e-6, flat
print("flat prices earn nothing       OK")

# Cheap early, expensive later: must charge before it discharges.
shaped = optimise_battery([10.0] * 6 + [100.0] * 6 + [10.0] * 6 + [100.0] * 6)
assert shaped["revenue"] > 0
assert min(shaped["charge_hours"]) < max(shaped["discharge_hours"])
for d in shaped["discharge_hours"]:
    assert any(c < d for c in shaped["charge_hours"]), "sold before buying"
print("chronology respected           OK")

# Expensive first, cheap after: no arbitrage is possible on a single day.
backwards = optimise_battery([100.0] * 12 + [10.0] * 12)
assert abs(backwards["revenue"]) < 1e-6, backwards
print("no free lunch on falling curve OK")

# Efficiency must bite: revenue below the frictionless spread.
m = compute_metrics(hourly[:1] + [80.0] + hourly[2:])
# Two capped cycles cannot beat the frictionless value of those same cycles.
frictionless = 2 * 2 * m["spread_2h"]
assert m["arb_revenue"] < frictionless, (m["arb_revenue"], frictionless)
assert m["cycles"] <= 2.0 + 1e-9, m["cycles"]
assert m["negative_hours"] == 2, m["negative_hours"]
print("efficiency loss applied        OK")
print(f"  sample day: base {m['base']}, spread {m['spread']}, "
      f"arbitrage {m['arb_revenue']} EUR/MW over {m['cycles']} cycles")

# The cycle cap must actually bind on a volatile day.
import fetch_prices as fp
saw = fp.MAX_CYCLES
fp.MAX_CYCLES = 1.0
capped = fp.optimise_battery([10.0,10.0,100.0,100.0]*6)
fp.MAX_CYCLES = saw
uncapped = fp.optimise_battery([10.0,10.0,100.0,100.0]*6)
assert capped["cycles"] <= 1.0 and uncapped["cycles"] > capped["cycles"]
assert uncapped["revenue"] > capped["revenue"]
print("cycle cap binds                OK")

# --- 5. Short day guard -----------------------------------------------------
assert to_local_hours(parse_series(build_xml("PT60M", hourly[:12])), date(2026, 8, 23), "Europe/Berlin") is None
print("incomplete days rejected       OK")
print("\nAll checks passed.")
